# Difference-Arrays-ArrayLists

## Overview
This project was created to show the difference between arrays and ArrayLists in Java. Arrays are fixed in size and require you to manage each index manually. ArrayLists are dynamic and come with useful built-in methods like `.add()` and `.remove()`.

## What it Does
- Prints out elements of a regular array
- Prints out elements of an ArrayList
- Demonstrates how ArrayLists can grow in size
- Has comments in the code explaining the differences

## Files
- DifferenceArraysArrayLists.java

## Author
Noelia Rodriguez
